# AI_ProblemSolving_ — Rule-Based Insurance Claim Decision System

## Problem Description

An insurance company needs an automated system to evaluate whether a claim should be **approved or rejected** based on predefined logical rules. The system uses propositional logic with facts such as:

- Policy validity (`policy_active`)
- Document verification (`documents_valid`)
- Accident reporting (`accident_reported`)
- Premium payment (`premium_paid`)
- Fraud detection (`fraud_detected`)

---

## Algorithm Used

### Rule-Based Inference — Forward Chaining (Propositional Logic)

The system implements **forward chaining**, a data-driven inference method:

1. A **Knowledge Base (KB)** is initialized with user-provided facts (True/False).
2. **Rules** in the form `IF condition(s) THEN outcome` are parsed.
3. The engine iterates over all rules repeatedly until no new facts can be derived.
4. Rules support:
   - `AND` conjunctions
   - `NOT` negation
   - Chained inference (derived facts trigger further rules)
5. A final **decision** is read from the KB: `final_approve`, `approve_claim`, or `reject_claim`.

---

## Sample Input & Output

### Input Facts
```
policy_active      = True
documents_valid    = True
accident_reported  = True
premium_paid       = False
fraud_detected     = False
```

### Rules
```
IF policy_active AND documents_valid THEN approve_claim
IF accident_reported AND NOT fraud_detected THEN accident_valid
IF accident_valid AND approve_claim THEN final_approve
IF fraud_detected THEN reject_claim
IF NOT premium_paid THEN reject_claim
IF NOT policy_active THEN reject_claim
```

### Output
```
[INPUT FACTS]
policy_active                  = TRUE
documents_valid                = TRUE
accident_reported              = TRUE
premium_paid                   = FALSE
fraud_detected                 = FALSE

[INFERENCE TRACE]
  [FIRED] Rule 1: policy_active AND documents_valid → approve_claim = TRUE
  [FIRED] Rule 2: accident_reported AND NOT fraud_detected → accident_valid = TRUE
  [FIRED] Rule 3: accident_valid AND approve_claim → final_approve = TRUE
  [FIRED] Rule 5: NOT premium_paid → reject_claim = TRUE

DECISION: CLAIM REJECTED
(reject_claim takes precedence — premium was not paid)
```

---

## Folder Structure

```
AI_ProblemSolving_/
├── README.md
├── insurance_claim/
│   ├── insurance_claim_system.py   # Main Python program
│   └── index.html                  # Interactive web interface
```

---

## Execution Steps

### Python (Console)
```bash
# Clone the repository
git clone https://github.com/yourusername/AI_ProblemSolving_
cd AI_ProblemSolving_/insurance_claim

# Run the program
python insurance_claim_system.py

# Select mode:
# 1 → Interactive (enter your own facts and rules)
# 2 → Demo (runs sample input from the problem statement)
```

### Web Interface
Open `index.html` in any modern browser — no server needed.

---

## Technologies

| Component | Technology |
|-----------|-----------|
| Core logic | Python 3.x |
| Web UI | HTML + CSS + Vanilla JS |
| Inference method | Forward Chaining (Propositional Logic) |
| Rule format | `IF cond1 AND NOT cond2 THEN outcome` |

---

## Key Design Decisions

- **Forward chaining** was chosen over backward chaining because we start with known facts and derive conclusions — natural for claim evaluation.
- **NOT support** allows rules like `IF NOT fraud_detected THEN ...` for nuanced logic.
- **Chained inference**: derived facts (e.g., `accident_valid`) can trigger further rules, enabling multi-step reasoning.
- **Reject priority**: if `reject_claim` is derived at any point, the claim is rejected regardless of approval conditions.
